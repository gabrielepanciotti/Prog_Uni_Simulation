Dentro de la carpeta VCode se encuentra el archivo SIM.sln,
que se tiene que abrir con Microsoft Visual Studio.

Cuando esté abierto, se puede ejecutar pulsando F5 o mediante el botón de play
que se encuentra en la parte de arriba.

Es posible que dé algunos problemas la versión del compilador, 
para solucionarlo hay que hacer lo siguiente:

En la parte superior de la ventana ir a Proyecto -> Propiedades -> Conjunto de herramientas de la plataforma, 
y ahí seleccionar la versión del compilador que queremos usar.

Para acceder a los archivos simplemente debemos hacer doble click en su nombre, 
en la parte derecha de la pantalla (archivos de encabezado, de código fuente...).